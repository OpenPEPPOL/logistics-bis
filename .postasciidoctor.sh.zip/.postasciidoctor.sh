#!/bin/sh

mv /target/guides/* /target/site/
rm -r /target/guides

